http_path = "/"
css_dir = "style"
sass_dir = "style/sass"
images_dir = "img"
javascripts_dir = "js"
output_style = :compressed
relative_assets=true
line_comments = false