//app js

function windowResize() {
	
}

//ready
$(function() {
	windowResize();
});